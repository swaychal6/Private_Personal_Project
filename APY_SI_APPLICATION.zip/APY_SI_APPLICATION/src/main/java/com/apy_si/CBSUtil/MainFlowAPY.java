package com.apy_si.CBSUtil;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.apy_si.dao.DatabaseMaster;
import com.apy_si.pojo.APY_MASTER_TRANSACTIONS;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class MainFlowAPY {

	private static final Logger logger_95 = LogManager.getLogger("95_JRGB");
	private static final Logger logger_96 = LogManager.getLogger("96_MBGB");
	private static final Logger logger_99 = LogManager.getLogger("99_UKGB");
	private static final Logger logger_102 = LogManager.getLogger("102_KVGB");
	private static final Logger logger_101 = LogManager.getLogger("101_ARGB");
	private static final Logger logger_1645 = LogManager.getLogger("1645_UTGB");
	private static final Logger logger_1653 = LogManager.getLogger("1653_CHGB");
	private static final Logger logger_1833 = LogManager.getLogger("1833_ELGB");
	private static final Logger logger_61 = LogManager.getLogger("61_ACRB");
	private static final Logger logger_62 = LogManager.getLogger("62_MZGB");
	private static final Logger logger_1859 = LogManager.getLogger("1859_APGVB");
	private static final Logger logger_1664 = LogManager.getLogger("1664_TGB");
	private static final Logger logger_374 = LogManager.getLogger("374_MGRB");
	private static final Logger logger_59 = LogManager.getLogger("59_NGRB");
	private static final Logger logger_108 = LogManager.getLogger("108_BOM");
	private static final Logger logger_27 = LogManager.getLogger("27_RMGB");
	private static final Logger logger_2213 = LogManager.getLogger("2213_SRGB");
	private static final Logger logger_251 = LogManager.getLogger("251_SPCB");

//	private static final Logger logger = LogManager.getLogger(APYController.class);
	private final DatabaseMaster databaseMaster;
	private final Rural_CBSUtilAPY rural_CBSUtilAPY;

	@Async
	public CompletableFuture<String> completableFuture(String frequency, String bank) {

		boolean isDone = false;
		Logger logger = getLoggerByBankCode(bank);

		logger.info("Program Started");

		logger.info("Starting transaction for bank: " + bank);

		List<APY_MASTER_TRANSACTIONS> list = databaseMaster.getApyMasterTransactions(bank, frequency);

		if (!list.isEmpty()) {

			for (APY_MASTER_TRANSACTIONS apy_MASTER_TRANSACTIONS : list) {
				logger.info("Pran:-" + apy_MASTER_TRANSACTIONS.getPRAN_NO() + " SI_DATE:-"
						+ apy_MASTER_TRANSACTIONS.getSI_DATE() + " AND PAID_UPTO_DATE:-"
						+ apy_MASTER_TRANSACTIONS.getPAID_UPTO_DATE());

				APY_MASTER_TRANSACTIONS APY_PRAN = databaseMaster.getRevisedPenaltyCount(apy_MASTER_TRANSACTIONS);
				isDone = rural_CBSUtilAPY.prepareCBSString(APY_PRAN, frequency);
				if (isDone) {
					logger.info("APY SI FOR PRAN:" + apy_MASTER_TRANSACTIONS.getPRAN_NO() + " is Completed.");
				} else {
					logger.info("APY SI FOR PRAN:" + apy_MASTER_TRANSACTIONS.getPRAN_NO() + " is Failed.");
				}
			}

		}


		logger.info("Program completed for Frequency:" + frequency + " and Bank:" + bank);

//		}

		return CompletableFuture.completedFuture("COmpleted");
	}


	public static Logger getLoggerByBankCode(String bankCode) {
		switch (bankCode) {
		case "95":
			return logger_95;
		case "96":
			return logger_96;
		case "99":
			return logger_99;
		case "102":
			return logger_102;
		case "101":
			return logger_101;
		case "1645":
			return logger_1645;
		case "1653":
			return logger_1653;
		case "1833":
			return logger_1833;
		case "61":
			return logger_61;
		case "62":
			return logger_62;
		case "1859":
			return logger_1859;
		case "1664":
			return logger_1664;
		case "374":
			return logger_374;
		case "59":
			return logger_59;
		case "108":
			return logger_108;
		case "27":
			return logger_27;
		case "2213":
			return logger_2213;
		case "251":
			return logger_251;
		default:
			throw new IllegalArgumentException("Invalid bank code: " + bankCode);
		}

//		private static final Logger logger_95 = LogManager.getLogger("95_BankCode");
//		private static final Logger logger_96 = LogManager.getLogger("96_BankCode");
//		private static final Logger logger_99 = LogManager.getLogger("99_BankCode");
//		private static final Logger logger_102 = LogManager.getLogger("102_BankCode");
//		private static final Logger logger_101 = LogManager.getLogger("101_BankCode");
//		private static final Logger logger_1645= LogManager.getLogger("1645_BankCode");
//		private static final Logger logger_1653 = LogManager.getLogger("1653_BankCode");
//		private static final Logger logger_1833 = LogManager.getLogger("1833_BankCode");
//		private static final Logger logger_61 = LogManager.getLogger("61_BankCode");
//		private static final Logger logger_62 = LogManager.getLogger("62_BankCode");
//		private static final Logger logger_1859 = LogManager.getLogger("1859_BankCode");
//		private static final Logger logger_1664 = LogManager.getLogger("1664_BankCode");
//		private static final Logger logger_374 = LogManager.getLogger("374_BankCode");
//		private static final Logger logger_59 = LogManager.getLogger("59_BankCode");
//		private static final Logger logger_108 = LogManager.getLogger("108_BankCode");
//		private static final Logger logger_27 = LogManager.getLogger("27_BankCode");
//		private static final Logger logger_2213= LogManager.getLogger("2213_BankCode");
//		private static final Logger logger_251 = LogManager.getLogger("251_BankCode");

	}

}
