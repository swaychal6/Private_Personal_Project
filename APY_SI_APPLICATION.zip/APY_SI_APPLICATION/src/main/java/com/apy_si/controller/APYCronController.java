package com.apy_si.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.apy_si.CBSUtil.MainFlowAPY;
import com.apy_si.CBSUtil.Rural_CBSUtilAPY;
import com.apy_si.dao.DatabaseMaster;
import com.apy_si.pojo.APY_MASTER_TRANSACTIONS;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/APY")
public class APYCronController {

	private static final Logger logger = LogManager.getLogger(APYCronController.class);


	private final MainFlowAPY mainFlowAPY;
	
	
	@PostMapping("/SI")
	@Scheduled(cron = "0 02 04 * * *")
	public void execute() {
//		logger.info("Program Started...");
		mainFlowAPY.completableFuture("M","95");
		mainFlowAPY.completableFuture("Q","95");
		mainFlowAPY.completableFuture("H","95");
//		logger.info("Program Completed...");
	}
	
	@PostMapping("/")
	@Scheduled(cron = "0 02 20 * * *")
	public void executeStart() {
		logger.info("Application screduler is Enabled and started Started...");
	}
	
	
	
	
	}


